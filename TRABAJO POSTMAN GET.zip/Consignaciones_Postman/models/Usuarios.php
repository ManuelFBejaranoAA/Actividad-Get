<?php
    class Usuarios extends Conectar{
        public function get_usuarios(){
            $conectar= parent::conexion();
            parent::set_names();
            $sql="SELECT * FROM consignaciones WHERE Codigo=1";
            $sql=$conectar->prepare($sql);
            $sql->execute();
            return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    class Usuarios extends Conectar{
        public function get_usuarios(){
            $conectar= parent::conexion();
            parent::set_names();
            $sql="SELECT * FROM consignaciones WHERE Codigo=1";
            $sql=$conectar->prepare($sql);
            $sql->execute();
            return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }
?>